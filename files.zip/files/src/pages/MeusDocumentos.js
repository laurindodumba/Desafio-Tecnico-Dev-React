import Breadcrumbs from "../components/Breadcrumbs";
import DocumentForm from "../components/DocumentForm";
import DocumentList from "../components/DocumentList";

const MeusDocumentos = () => {
    return (
        <div>
            <Breadcrumbs />
            <h2>Meus Documentos</h2>
            <DocumentForm />
            <DocumentList />
        </div>
    );
};

export default MeusDocumentos;
