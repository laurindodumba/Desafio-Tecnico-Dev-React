import React from "react";
import { FaFileAlt } from "react-icons/fa"; // Importa o ícone

const Home = () => {
    return (
        <div className="home-container">
            <h1>Bem-vindo ao Upload de Documentos</h1>
            
            {/* Ícone de Documentos */}
            <div className="icon-container">
                <FaFileAlt size={50} color="#004aad" /> {/* Ajuste o tamanho e cor */}
                <p>Meus Documentos</p>
            </div>
        </div>
    );
};

export default Home;
