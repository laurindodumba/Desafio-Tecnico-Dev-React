import React from "react";
import { Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import MeusDocumentos from "./pages/MeusDocumentos";
import Navbar from "./components/Navbar";
import Sidebar from "./components/Sidebar";
import "./App.css";

function App() {
    return (
        <>
            <Navbar />
            <div className="container">
                <Sidebar />
                <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/meus-documentos" element={<MeusDocumentos />} />
                </Routes>
            </div>
        </>
    );
}

export default App;
