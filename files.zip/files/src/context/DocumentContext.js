import { createContext, useState } from "react";

// Criando o contexto
const DocumentContext = createContext();

// Criando o provedor do contexto
export const DocumentProvider = ({ children }) => {
    const [documents, setDocuments] = useState([]);

    return (
        <DocumentContext.Provider value={{ documents, setDocuments }}>
            {children}
        </DocumentContext.Provider>
    );
};

// Exportando o contexto como padrão e também nomeado
export { DocumentContext };
export default DocumentContext;
