import { useState, useContext } from "react";
import { DocumentContext } from "../context/DocumentContext";

const DocumentForm = () => {
    const { documents, setDocuments } = useContext(DocumentContext);
    const [title, setTitle] = useState("");
    const [description, setDescription] = useState("");
    const [file, setFile] = useState(null);

    const handleSubmit = (e) => {
        e.preventDefault();

        if (title.length > 100) return alert("Título deve ter no máximo 100 caracteres.");
        if (description.length > 2000) return alert("Descrição deve ter no máximo 2000 caracteres.");
        if (documents.some((doc) => doc.title === title)) return alert("Documento com esse título já existe.");

        const forbiddenExtensions = [".exe", ".zip", ".bat"];
        if (file && forbiddenExtensions.some(ext => file.name.endsWith(ext))) {
            return alert("Tipo de arquivo não permitido.");
        }

        setDocuments([...documents, { title, description, file }]);

        setTitle("");
        setDescription("");
        setFile(null);
    };

    return (
        <form onSubmit={handleSubmit}>
            <input type="text" placeholder="Título" value={title} onChange={(e) => setTitle(e.target.value)} required />
            <textarea placeholder="Descrição" value={description} onChange={(e) => setDescription(e.target.value)} required />
            <input type="file" onChange={(e) => setFile(e.target.files[0])} required />
            <button type="submit">Adicionar Documento</button>
        </form>
    );
};

export default DocumentForm;
