import { Link } from "react-router-dom";

const Sidebar = () => {
    return (
        <div className="sidebar">
            <ul>
                <li><Link to="/">Início</Link></li>
                <li><Link to="/meus-documentos">Meus Documentos</Link></li>
            </ul>
        </div>
    );
};

export default Sidebar;
