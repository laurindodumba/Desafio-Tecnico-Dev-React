const Navbar = () => {
    return (
        <div className="navbar">
            <h1>docApp</h1>
        </div>
    );
};

export default Navbar;
