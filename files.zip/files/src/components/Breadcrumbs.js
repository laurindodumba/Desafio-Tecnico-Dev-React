import { useLocation } from "react-router-dom";




const Breadcrumbs = () => {
    const location = useLocation();
    const pathnames = location.pathname.split("/").filter((x) => x);


    return (
        <div className="breadcrumbs">
            <span>Início</span>
            {pathnames.map((name, index) => (
                <span key={index}>  {name}</span>
            ))}
        </div>
    );
};

export default Breadcrumbs;