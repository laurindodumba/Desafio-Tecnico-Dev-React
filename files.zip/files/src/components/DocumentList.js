import { useContext } from "react";
import { DocumentContext } from "../context/DocumentContext";

const DocumentList = () => {
    const { documents, setDocuments } = useContext(DocumentContext);

    const deleteDocument = (title) => {
        setDocuments(documents.filter(doc => doc.title !== title));
    };

    return (
        <div>
            {documents.length === 0 ? <p>Nenhum documento cadastrado.</p> : (
                <ul>
                    {documents.map((doc, index) => (
                        <li key={index}>
                            <strong>{doc.title}</strong>
                            <p>{doc.description}</p>
                            <button onClick={() => deleteDocument(doc.title)}>Excluir</button>
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
};

export default DocumentList;
